                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.3.1-pj3 Thu Oct 23 20:19:50 2014
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module cfunc
                              7 	
                              8 ;--------------------------------------------------------
                              9 ; Public variables in this module
                             10 ;--------------------------------------------------------
                             11 	.globl _main
                             12 	.globl _c_func
                             13 	.globl _c_func_PARM_2
                             14 	.globl _abc
                             15 	.globl _getchar
                             16 	.globl _putchar
                             17 	.globl _init
                             18 ;--------------------------------------------------------
                             19 ; special function registers
                             20 ;--------------------------------------------------------
                    00E0     21 _ACC	=	0x00e0
                    00F0     22 _B	=	0x00f0
                    0083     23 _DPH	=	0x0083
                    0083     24 _DP0H	=	0x0083
                    0082     25 _DPL	=	0x0082
                    0082     26 _DP0L	=	0x0082
                    00A8     27 _IE	=	0x00a8
                    00B8     28 _IP	=	0x00b8
                    0080     29 _P0	=	0x0080
                    0090     30 _P1	=	0x0090
                    00A0     31 _P2	=	0x00a0
                    00B0     32 _P3	=	0x00b0
                    0087     33 _PCON	=	0x0087
                    00D0     34 _PSW	=	0x00d0
                    0099     35 _SBUF	=	0x0099
                    0099     36 _SBUF0	=	0x0099
                    0098     37 _SCON	=	0x0098
                    0081     38 _SP	=	0x0081
                    0088     39 _TCON	=	0x0088
                    008C     40 _TH0	=	0x008c
                    008D     41 _TH1	=	0x008d
                    008A     42 _TL0	=	0x008a
                    008B     43 _TL1	=	0x008b
                    0089     44 _TMOD	=	0x0089
                             45 ;--------------------------------------------------------
                             46 ; special function bits 
                             47 ;--------------------------------------------------------
                    00F0     48 _BREG_F0	=	0x00f0
                    00F1     49 _BREG_F1	=	0x00f1
                    00F2     50 _BREG_F2	=	0x00f2
                    00F3     51 _BREG_F3	=	0x00f3
                    00F4     52 _BREG_F4	=	0x00f4
                    00F5     53 _BREG_F5	=	0x00f5
                    00F6     54 _BREG_F6	=	0x00f6
                    00F7     55 _BREG_F7	=	0x00f7
                    00A8     56 _EX0	=	0x00a8
                    00A9     57 _ET0	=	0x00a9
                    00AA     58 _EX1	=	0x00aa
                    00AB     59 _ET1	=	0x00ab
                    00AC     60 _ES	=	0x00ac
                    00AF     61 _EA	=	0x00af
                    00B8     62 _PX0	=	0x00b8
                    00B9     63 _PT0	=	0x00b9
                    00BA     64 _PX1	=	0x00ba
                    00BB     65 _PT1	=	0x00bb
                    00BC     66 _PS	=	0x00bc
                    0080     67 _P0_0	=	0x0080
                    0081     68 _P0_1	=	0x0081
                    0082     69 _P0_2	=	0x0082
                    0083     70 _P0_3	=	0x0083
                    0084     71 _P0_4	=	0x0084
                    0085     72 _P0_5	=	0x0085
                    0086     73 _P0_6	=	0x0086
                    0087     74 _P0_7	=	0x0087
                    0090     75 _P1_0	=	0x0090
                    0091     76 _P1_1	=	0x0091
                    0092     77 _P1_2	=	0x0092
                    0093     78 _P1_3	=	0x0093
                    0094     79 _P1_4	=	0x0094
                    0095     80 _P1_5	=	0x0095
                    0096     81 _P1_6	=	0x0096
                    0097     82 _P1_7	=	0x0097
                    00A0     83 _P2_0	=	0x00a0
                    00A1     84 _P2_1	=	0x00a1
                    00A2     85 _P2_2	=	0x00a2
                    00A3     86 _P2_3	=	0x00a3
                    00A4     87 _P2_4	=	0x00a4
                    00A5     88 _P2_5	=	0x00a5
                    00A6     89 _P2_6	=	0x00a6
                    00A7     90 _P2_7	=	0x00a7
                    00B0     91 _P3_0	=	0x00b0
                    00B1     92 _P3_1	=	0x00b1
                    00B2     93 _P3_2	=	0x00b2
                    00B3     94 _P3_3	=	0x00b3
                    00B4     95 _P3_4	=	0x00b4
                    00B5     96 _P3_5	=	0x00b5
                    00B6     97 _P3_6	=	0x00b6
                    00B7     98 _P3_7	=	0x00b7
                    00B0     99 _RXD	=	0x00b0
                    00B0    100 _RXD0	=	0x00b0
                    00B1    101 _TXD	=	0x00b1
                    00B1    102 _TXD0	=	0x00b1
                    00B2    103 _INT0	=	0x00b2
                    00B3    104 _INT1	=	0x00b3
                    00B4    105 _T0	=	0x00b4
                    00B5    106 _T1	=	0x00b5
                    00B6    107 _WR	=	0x00b6
                    00B7    108 _RD	=	0x00b7
                    00D0    109 _P	=	0x00d0
                    00D1    110 _F1	=	0x00d1
                    00D2    111 _OV	=	0x00d2
                    00D3    112 _RS0	=	0x00d3
                    00D4    113 _RS1	=	0x00d4
                    00D5    114 _F0	=	0x00d5
                    00D6    115 _AC	=	0x00d6
                    00D7    116 _CY	=	0x00d7
                    0098    117 _RI	=	0x0098
                    0099    118 _TI	=	0x0099
                    009A    119 _RB8	=	0x009a
                    009B    120 _TB8	=	0x009b
                    009C    121 _REN	=	0x009c
                    009D    122 _SM2	=	0x009d
                    009E    123 _SM1	=	0x009e
                    009F    124 _SM0	=	0x009f
                    0088    125 _IT0	=	0x0088
                    0089    126 _IE0	=	0x0089
                    008A    127 _IT1	=	0x008a
                    008B    128 _IE1	=	0x008b
                    008C    129 _TR0	=	0x008c
                    008D    130 _TF0	=	0x008d
                    008E    131 _TR1	=	0x008e
                    008F    132 _TF1	=	0x008f
                            133 ;--------------------------------------------------------
                            134 ; internal ram data
                            135 ;--------------------------------------------------------
                            136 	.area DSEG    (DATA)
   0030                     137 _c_func_PARM_2::
   0030                     138 	.ds 1
                            139 ;--------------------------------------------------------
                            140 ; overlayable items in internal ram 
                            141 ;--------------------------------------------------------
                            142 	.area	OSEG    (OVR,DATA)
                            143 ;--------------------------------------------------------
                            144 ; Stack segment in internal ram 
                            145 ;--------------------------------------------------------
                            146 	.area	SSEG	(DATA)
   0045                     147 __start__stack:
   0045                     148 	.ds	1
                            149 
                            150 ;--------------------------------------------------------
                            151 ; indirectly addressable internal ram data
                            152 ;--------------------------------------------------------
                            153 	.area ISEG    (DATA)
                            154 ;--------------------------------------------------------
                            155 ; bit data
                            156 ;--------------------------------------------------------
                            157 	.area BSEG    (BIT)
                            158 ;--------------------------------------------------------
                            159 ; external ram data
                            160 ;--------------------------------------------------------
                            161 	.area XSEG    (XDATA)
                            162 ;--------------------------------------------------------
                            163 ; external initialized ram data
                            164 ;--------------------------------------------------------
                            165 	.area XISEG   (XDATA)
                            166 ;--------------------------------------------------------
                            167 ; interrupt vector 
                            168 ;--------------------------------------------------------
                            169 	.area CSEG    (CODE)
   0000                     170 __interrupt_vect:
   0000 02 08 54            171 	ljmp	__sdcc_gsinit_startup
   0003 32                  172 	reti
   0004                     173 	.ds	7
   000B 32                  174 	reti
   000C                     175 	.ds	7
   0013 32                  176 	reti
   0014                     177 	.ds	7
   001B 32                  178 	reti
   001C                     179 	.ds	7
   0023 32                  180 	reti
   0024                     181 	.ds	7
   002B 32                  182 	reti
   002C                     183 	.ds	7
                            184 ;--------------------------------------------------------
                            185 ; global & static initialisations
                            186 ;--------------------------------------------------------
                            187 	.area GSINIT  (CODE)
                            188 	.area GSFINAL (CODE)
                            189 	.area GSINIT  (CODE)
   0854                     190 __sdcc_gsinit_startup:
   0854 75 81 07            191 	mov	sp,#7
   0857 12 00 F1            192 	lcall	__sdcc_external_startup
   085A E5 82               193 	mov	a,dpl
   085C 60 03               194 	jz	__sdcc_init_data
   085E 02 00 33            195 	ljmp	__sdcc_program_startup
   0861                     196 __sdcc_init_data:
                            197 ;	_mcs51_genXINIT() start
   0861 74 00               198 	mov	a,#l_XINIT
   0863 44 00               199 	orl	a,#l_XINIT>>8
   0865 60 29               200 	jz	00003$
   0867 74 93               201 	mov	a,#s_XINIT
   0869 24 00               202 	add	a,#l_XINIT
   086B F9                  203 	mov	r1,a
   086C 74 08               204 	mov	a,#s_XINIT>>8
   086E 34 00               205 	addc	a,#l_XINIT>>8
   0870 FA                  206 	mov	r2,a
   0871 90 08 93            207 	mov	dptr,#s_XINIT
   0874 78 00               208 	mov	r0,#s_XISEG
   0876 75 A0 00            209 	mov	p2,#(s_XISEG >> 8)
   0879 E4                  210 00001$:	clr	a
   087A 93                  211 	movc	a,@a+dptr
   087B F2                  212 	movx	@r0,a
   087C A3                  213 	inc	dptr
   087D 08                  214 	inc	r0
   087E B8 00 02            215 	cjne	r0,#0,00002$
   0881 05 A0               216 	inc	p2
   0883 E5 82               217 00002$:	mov	a,dpl
   0885 B5 01 F1            218 	cjne	a,ar1,00001$
   0888 E5 83               219 	mov	a,dph
   088A B5 02 EC            220 	cjne	a,ar2,00001$
   088D 75 A0 FF            221 	mov	p2,#0xFF
   0890                     222 00003$:
                            223 ;	_mcs51_genXINIT() end
                            224 	.area GSFINAL (CODE)
   0890 02 00 33            225 	ljmp	__sdcc_program_startup
                            226 ;--------------------------------------------------------
                            227 ; Home
                            228 ;--------------------------------------------------------
                            229 	.area HOME    (CODE)
                            230 	.area CSEG    (CODE)
                            231 ;--------------------------------------------------------
                            232 ; code
                            233 ;--------------------------------------------------------
                            234 	.area CSEG    (CODE)
   0033                     235 __sdcc_program_startup:
   0033 12 00 60            236 	lcall	_main
                            237 ;	return from main will lock up
   0036 80 FE               238 	sjmp .
                            239 ;------------------------------------------------------------
                            240 ;Allocation info for local variables in function 'abc'
                            241 ;------------------------------------------------------------
                            242 ;x                         Allocated to registers r2 r3 
                            243 ;	cfunc.c 11
                            244 ;	-----------------------------------------
                            245 ;	 function abc
                            246 ;	-----------------------------------------
   0038                     247 _abc:
                    0002    248 	ar2 = 0x02
                    0003    249 	ar3 = 0x03
                    0004    250 	ar4 = 0x04
                    0005    251 	ar5 = 0x05
                    0006    252 	ar6 = 0x06
                    0007    253 	ar7 = 0x07
                    0000    254 	ar0 = 0x00
                    0001    255 	ar1 = 0x01
                            256 ;	cfunc.c 0
                            257 ;	genReceive
   0038 AA 82               258 	mov	r2,dpl
   003A AB 83               259 	mov	r3,dph
                            260 ;	cfunc.c 13
                            261 ;	genIpush
   003C C0 02               262 	push	ar2
   003E C0 03               263 	push	ar3
                            264 ;	genIpush
   0040 74 B1               265 	mov	a,#__str_0
   0042 C0 E0               266 	push	acc
   0044 74 00               267 	mov	a,#(__str_0 >> 8)
   0046 C0 E0               268 	push	acc
   0048 74 02               269 	mov	a,#0x02
   004A C0 E0               270 	push	acc
                            271 ;	genCall
   004C 12 00 F5            272 	lcall	_printf
   004F E5 81               273 	mov	a,sp
   0051 24 FB               274 	add	a,#0xfb
   0053 F5 81               275 	mov	sp,a
                            276 ;	cfunc.c 14
                            277 ;	genRet
                            278 ; Peephole 181   used 16 bit load of dptr
   0055 90 00 00            279 	mov  dptr,#0x0000
   0058                     280 00101$:
   0058 22                  281 	ret
                            282 ;------------------------------------------------------------
                            283 ;Allocation info for local variables in function 'c_func'
                            284 ;------------------------------------------------------------
                            285 ;j                         Allocated to in memory with name '_c_func_PARM_2'
                            286 ;i                         Allocated to registers 
                            287 ;	cfunc.c 17
                            288 ;	-----------------------------------------
                            289 ;	 function c_func
                            290 ;	-----------------------------------------
   0059                     291 _c_func:
                            292 ;	cfunc.c 19
                            293 ;	genReceive
                            294 ;	genAssign
   0059 85 30 44            295 	mov	_asm_func_PARM_2,_c_func_PARM_2
                            296 ;	genCall
   005C 12 00 E0            297 	lcall	_asm_func
                            298 ;	genRet
   005F                     299 00101$:
   005F 22                  300 	ret
                            301 ;------------------------------------------------------------
                            302 ;Allocation info for local variables in function 'main'
                            303 ;------------------------------------------------------------
                            304 ;x                         Allocated to registers 
                            305 ;	cfunc.c 23
                            306 ;	-----------------------------------------
                            307 ;	 function main
                            308 ;	-----------------------------------------
   0060                     309 _main:
                            310 ;	cfunc.c 26
                            311 ;	genCall
   0060 12 00 A3            312 	lcall	_init
                            313 ;	cfunc.c 27
                            314 ;	genAssign
   0063 75 30 06            315 	mov	_c_func_PARM_2,#0x06
                            316 ;	genCall
   0066 75 82 02            317 	mov	dpl,#0x02
   0069 12 00 59            318 	lcall	_c_func
   006C E5 82               319 	mov	a,dpl
   006E 85 83 F0            320 	mov	b,dph
                            321 ;	cfunc.c 28
                            322 ;	genIpush
                            323 ;  Peephole 100.a   removed redundant mov
   0071 C0 E0               324 	push	acc
   0073 E5 F0               325 	mov	a,b
   0075 C0 E0               326 	push	acc
                            327 ;	genIpush
   0077 74 B4               328 	mov	a,#__str_1
   0079 C0 E0               329 	push	acc
   007B 74 00               330 	mov	a,#(__str_1 >> 8)
   007D C0 E0               331 	push	acc
   007F 74 02               332 	mov	a,#0x02
   0081 C0 E0               333 	push	acc
                            334 ;	genCall
   0083 12 00 F5            335 	lcall	_printf
   0086 E5 81               336 	mov	a,sp
   0088 24 FB               337 	add	a,#0xfb
   008A F5 81               338 	mov	sp,a
                            339 ;	cfunc.c 29
                            340 ;	genRet
                            341 ; Peephole 181   used 16 bit load of dptr
   008C 90 00 00            342 	mov  dptr,#0x0000
   008F                     343 00101$:
   008F 22                  344 	ret
                            345 ;------------------------------------------------------------
                            346 ;Allocation info for local variables in function 'getchar'
                            347 ;------------------------------------------------------------
                            348 ;	cfunc.c 33
                            349 ;	-----------------------------------------
                            350 ;	 function getchar
                            351 ;	-----------------------------------------
   0090                     352 _getchar:
                            353 ;	cfunc.c 35
   0090                     354 00101$:
                            355 ;	genIfx
                            356 ;	genIfxJump
                            357 ; Peephole 111   removed ljmp by inverse jump logic
   0090 30 98 FD            358 	jnb  _RI,00101$
   0093                     359 00108$:
                            360 ;	cfunc.c 36
                            361 ;	genAssign
   0093 C2 98               362 	clr	_RI
                            363 ;	cfunc.c 37
                            364 ;	genAssign
   0095 85 99 82            365 	mov	dpl,_SBUF
                            366 ;	genRet
   0098                     367 00104$:
   0098 22                  368 	ret
                            369 ;------------------------------------------------------------
                            370 ;Allocation info for local variables in function 'putchar'
                            371 ;------------------------------------------------------------
                            372 ;	cfunc.c 41
                            373 ;	-----------------------------------------
                            374 ;	 function putchar
                            375 ;	-----------------------------------------
   0099                     376 _putchar:
                            377 ;	cfunc.c 45
                            378 ;	genReceive
   0099 AA 82               379 	mov	r2,dpl
                            380 ;	cfunc.c 43
   009B                     381 00101$:
                            382 ;	genIfx
                            383 ;	genIfxJump
                            384 ; Peephole 111   removed ljmp by inverse jump logic
   009B 30 99 FD            385 	jnb  _TI,00101$
   009E                     386 00108$:
                            387 ;	cfunc.c 44
                            388 ;	genAssign
   009E 8A 99               389 	mov	_SBUF,r2
                            390 ;	cfunc.c 45
                            391 ;	genAssign
   00A0 C2 99               392 	clr	_TI
   00A2                     393 00104$:
   00A2 22                  394 	ret
                            395 ;------------------------------------------------------------
                            396 ;Allocation info for local variables in function 'init'
                            397 ;------------------------------------------------------------
                            398 ;	cfunc.c 48
                            399 ;	-----------------------------------------
                            400 ;	 function init
                            401 ;	-----------------------------------------
   00A3                     402 _init:
                            403 ;	cfunc.c 50
                            404 ;	genAssign
   00A3 75 98 50            405 	mov	_SCON,#0x50
                            406 ;	cfunc.c 51
                            407 ;	genAssign
   00A6 75 89 20            408 	mov	_TMOD,#0x20
                            409 ;	cfunc.c 52
                            410 ;	genAssign
   00A9 75 8D FD            411 	mov	_TH1,#0xFD
                            412 ;	cfunc.c 53
                            413 ;	genAssign
   00AC D2 8E               414 	setb	_TR1
                            415 ;	cfunc.c 54
                            416 ;	genAssign
   00AE D2 99               417 	setb	_TI
   00B0                     418 00101$:
   00B0 22                  419 	ret
                            420 	.area CSEG    (CODE)
   00B1                     421 __str_0:
   00B1 25 64               422 	.ascii "%d"
   00B3 00                  423 	.db 0x00
   00B4                     424 __str_1:
   00B4 0A                  425 	.db 0x0A
   00B5 0D                  426 	.db 0x0D
   00B6 41 64 64 69 74 69   427 	.ascii "Addition of number a and number b is %d"
        6F 6E 20 6F 66 20
        6E 75 6D 62 65 72
        20 61 20 61 6E 64
        20 6E 75 6D 62 65
        72 20 62 20 69 73
        20 25 64
   00DD 0A                  428 	.db 0x0A
   00DE 0D                  429 	.db 0x0D
   00DF 00                  430 	.db 0x00
                            431 	.area	XINIT   (CODE)
